import { useTranslation } from "react-i18next";
import { useNavigate } from "@tanstack/react-router";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function UpgradeModal({
  open,
  onOpenChange,
  reason,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  reason?: "quota" | "no_plan" | "image_limit";
}) {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const isNoPlan = reason === "no_plan";
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {isNoPlan ? t("upgrade.noPlanTitle") : t("upgrade.limitReachedTitle")}
          </DialogTitle>
          <DialogDescription>
            {isNoPlan ? t("upgrade.noPlanMessage") : t("upgrade.limitReachedMessage")}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            {t("common.close")}
          </Button>
          <Button
            onClick={() => {
              onOpenChange(false);
              navigate({ to: "/pricing" });
            }}
          >
            {t("upgrade.upgradeButton")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
