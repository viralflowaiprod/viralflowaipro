export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      activation_codes: {
        Row: {
          buyer_email: string | null
          code: string
          created_at: string
          expires_at: string | null
          external_order_id: string | null
          id: string
          is_master: boolean
          plan_tier: string
          source: string
          status: string
          updated_at: string
          used_at: string | null
          used_by: string | null
        }
        Insert: {
          buyer_email?: string | null
          code: string
          created_at?: string
          expires_at?: string | null
          external_order_id?: string | null
          id?: string
          is_master?: boolean
          plan_tier?: string
          source: string
          status?: string
          updated_at?: string
          used_at?: string | null
          used_by?: string | null
        }
        Update: {
          buyer_email?: string | null
          code?: string
          created_at?: string
          expires_at?: string | null
          external_order_id?: string | null
          id?: string
          is_master?: boolean
          plan_tier?: string
          source?: string
          status?: string
          updated_at?: string
          used_at?: string | null
          used_by?: string | null
        }
        Relationships: []
      }
      api_keys: {
        Row: {
          api_key: string
          created_at: string
          current_usage: number
          daily_limit: number | null
          id: string
          provider: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          api_key: string
          created_at?: string
          current_usage?: number
          daily_limit?: number | null
          id?: string
          provider: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          api_key?: string
          created_at?: string
          current_usage?: number
          daily_limit?: number | null
          id?: string
          provider?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          ip_address: string | null
          metadata: Json
          target_id: string | null
          target_type: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          ip_address?: string | null
          metadata?: Json
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          ip_address?: string | null
          metadata?: Json
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      automation_logs: {
        Row: {
          created_at: string
          id: string
          job_id: string | null
          level: string
          message: string
          metadata: Json | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          job_id?: string | null
          level?: string
          message: string
          metadata?: Json | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          job_id?: string | null
          level?: string
          message?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "automation_logs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "video_jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      automation_settings: {
        Row: {
          continuous_monthly: boolean
          created_at: string
          current_job_id: string | null
          daily_quantity: number
          enabled: boolean
          id: string
          last_resume_at: string | null
          mode: string
          niche: string | null
          paused: boolean
          platforms: Json
          seed_idea: string | null
          time_slots: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          continuous_monthly?: boolean
          created_at?: string
          current_job_id?: string | null
          daily_quantity?: number
          enabled?: boolean
          id?: string
          last_resume_at?: string | null
          mode?: string
          niche?: string | null
          paused?: boolean
          platforms?: Json
          seed_idea?: string | null
          time_slots?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          continuous_monthly?: boolean
          created_at?: string
          current_job_id?: string | null
          daily_quantity?: number
          enabled?: boolean
          id?: string
          last_resume_at?: string | null
          mode?: string
          niche?: string | null
          paused?: boolean
          platforms?: Json
          seed_idea?: string | null
          time_slots?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      connected_accounts: {
        Row: {
          access_token: string | null
          account_name: string | null
          created_at: string
          expires_at: string | null
          id: string
          platform: string
          refresh_token: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token?: string | null
          account_name?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          platform: string
          refresh_token?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string | null
          account_name?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          platform?: string
          refresh_token?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      plans: {
        Row: {
          checkout_url_kiwify: string | null
          checkout_url_stripe: string | null
          created_at: string
          features: Json
          is_active: boolean
          name: string
          own_images_per_video: number
          price_brl_cents: number
          price_eur_cents: number
          price_usd_cents: number
          slug: string
          tier_order: number
          updated_at: string
          videos_per_day: number
          videos_per_month: number
        }
        Insert: {
          checkout_url_kiwify?: string | null
          checkout_url_stripe?: string | null
          created_at?: string
          features?: Json
          is_active?: boolean
          name: string
          own_images_per_video?: number
          price_brl_cents?: number
          price_eur_cents?: number
          price_usd_cents?: number
          slug: string
          tier_order: number
          updated_at?: string
          videos_per_day?: number
          videos_per_month?: number
        }
        Update: {
          checkout_url_kiwify?: string | null
          checkout_url_stripe?: string | null
          created_at?: string
          features?: Json
          is_active?: boolean
          name?: string
          own_images_per_video?: number
          price_brl_cents?: number
          price_eur_cents?: number
          price_usd_cents?: number
          slug?: string
          tier_order?: number
          updated_at?: string
          videos_per_day?: number
          videos_per_month?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          locale: string
          privacy_mode: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          locale?: string
          privacy_mode?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          locale?: string
          privacy_mode?: string
          updated_at?: string
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          bucket: string
          count: number
          created_at: string
          id: string
          identifier: string
          window_start: string
        }
        Insert: {
          bucket: string
          count?: number
          created_at?: string
          id?: string
          identifier: string
          window_start?: string
        }
        Update: {
          bucket?: string
          count?: number
          created_at?: string
          id?: string
          identifier?: string
          window_start?: string
        }
        Relationships: []
      }
      scheduled_posts: {
        Row: {
          caption: string | null
          created_at: string
          id: string
          platform: string
          scheduled_for: string
          status: string
          updated_at: string
          user_id: string
          video_id: string | null
        }
        Insert: {
          caption?: string | null
          created_at?: string
          id?: string
          platform: string
          scheduled_for: string
          status?: string
          updated_at?: string
          user_id: string
          video_id?: string | null
        }
        Update: {
          caption?: string | null
          created_at?: string
          id?: string
          platform?: string
          scheduled_for?: string
          status?: string
          updated_at?: string
          user_id?: string
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "scheduled_posts_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          buyer_email: string | null
          cancelled_at: string | null
          code_id: string | null
          created_at: string
          current_period_end: string | null
          external_order_id: string | null
          id: string
          plan_slug: string | null
          plan_tier: string
          source: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          buyer_email?: string | null
          cancelled_at?: string | null
          code_id?: string | null
          created_at?: string
          current_period_end?: string | null
          external_order_id?: string | null
          id?: string
          plan_slug?: string | null
          plan_tier?: string
          source?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          buyer_email?: string | null
          cancelled_at?: string | null
          code_id?: string | null
          created_at?: string
          current_period_end?: string | null
          external_order_id?: string | null
          id?: string
          plan_slug?: string | null
          plan_tier?: string
          source?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_code_id_fkey"
            columns: ["code_id"]
            isOneToOne: false
            referencedRelation: "activation_codes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_plan_slug_fkey"
            columns: ["plan_slug"]
            isOneToOne: false
            referencedRelation: "plans"
            referencedColumns: ["slug"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      video_jobs: {
        Row: {
          created_at: string
          cta: string | null
          error: string | null
          error_message: string | null
          id: string
          niche: string | null
          payload: Json | null
          platform: string | null
          progress: number
          prompt: string | null
          quantity: number
          reference_images: Json
          status: string
          theme: string | null
          topic: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          cta?: string | null
          error?: string | null
          error_message?: string | null
          id?: string
          niche?: string | null
          payload?: Json | null
          platform?: string | null
          progress?: number
          prompt?: string | null
          quantity?: number
          reference_images?: Json
          status?: string
          theme?: string | null
          topic?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          cta?: string | null
          error?: string | null
          error_message?: string | null
          id?: string
          niche?: string | null
          payload?: Json | null
          platform?: string | null
          progress?: number
          prompt?: string | null
          quantity?: number
          reference_images?: Json
          status?: string
          theme?: string | null
          topic?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      videos: {
        Row: {
          created_at: string
          cta: string | null
          duration: number | null
          hook: string | null
          id: string
          niche: string | null
          platform: string | null
          script: string | null
          status: string
          theme: string | null
          thumbnail_url: string | null
          title: string
          updated_at: string
          user_id: string
          video_url: string | null
        }
        Insert: {
          created_at?: string
          cta?: string | null
          duration?: number | null
          hook?: string | null
          id?: string
          niche?: string | null
          platform?: string | null
          script?: string | null
          status?: string
          theme?: string | null
          thumbnail_url?: string | null
          title: string
          updated_at?: string
          user_id: string
          video_url?: string | null
        }
        Update: {
          created_at?: string
          cta?: string | null
          duration?: number | null
          hook?: string | null
          id?: string
          niche?: string | null
          platform?: string | null
          script?: string | null
          status?: string
          theme?: string | null
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
          user_id?: string
          video_url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_rate_limit: {
        Args: {
          _bucket: string
          _identifier: string
          _max: number
          _window_seconds: number
        }
        Returns: boolean
      }
      check_video_quota: { Args: { _user_id: string }; Returns: Json }
      count_videos_in_period: {
        Args: { _since: string; _user_id: string }
        Returns: number
      }
      get_plan_limits: {
        Args: { _slug: string }
        Returns: {
          own_images_per_video: number
          videos_per_day: number
          videos_per_month: number
        }[]
      }
      get_user_plan: { Args: { _user_id: string }; Returns: string }
      has_active_subscription: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
      log_audit_event: {
        Args: {
          _action: string
          _ip?: string
          _metadata?: Json
          _target_id?: string
          _target_type?: string
          _ua?: string
          _user_id: string
        }
        Returns: string
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
