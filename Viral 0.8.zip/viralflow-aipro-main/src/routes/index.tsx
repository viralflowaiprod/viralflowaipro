import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  // Paywall/landing temporariamente desativado — redireciona direto para o cadastro.
  // TODO: reativar a landing page após criar a conta admin.
  beforeLoad: () => {
    throw redirect({ to: "/signup" });
  },
});
