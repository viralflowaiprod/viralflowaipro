import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Schema = z.object({
  job_id: z.string().uuid(),
  user_id: z.string().uuid().optional(),
  stage: z.enum(["script", "tts", "images", "assembly", "publish"]).optional(),
  progress: z.number().int().min(0).max(100).optional(),
  status: z.enum(["processing", "completed", "failed"]).optional(),
  message: z.string().max(2000).optional(),
  video_url: z.string().url().optional(),
  thumbnail_url: z.string().url().optional(),
  title: z.string().max(200).optional(),
  error: z.string().max(2000).optional(),
});

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export const Route = createFileRoute("/api/public/hooks/video-progress")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        // Verify shared secret
        const expected = process.env.N8N_WEBHOOK_SECRET ?? "";
        const provided = request.headers.get("x-webhook-secret") ?? "";
        if (!expected || !provided || !timingSafeEqual(provided, expected)) {
          return new Response("Unauthorized", { status: 401 });
        }

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }
        const parsed = Schema.safeParse(body);
        if (!parsed.success) {
          return new Response(
            JSON.stringify({ error: "Validation failed", issues: parsed.error.issues }),
            { status: 400, headers: { "Content-Type": "application/json" } },
          );
        }
        const p = parsed.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const update: { updated_at: string; progress?: number; status?: string; error_message?: string } = {
          updated_at: new Date().toISOString(),
        };
        if (p.progress !== undefined) update.progress = p.progress;
        if (p.status) update.status = p.status;
        if (p.error) update.error_message = p.error;

        await supabaseAdmin.from("video_jobs").update(update).eq("id", p.job_id);

        await supabaseAdmin.from("automation_logs").insert({
          job_id: p.job_id,
          user_id: p.user_id ?? null,
          level: p.status === "failed" || p.error ? "error" : "info",
          message: p.message ?? `Stage: ${p.stage ?? "unknown"}`,
          metadata: { stage: p.stage, progress: p.progress, status: p.status },
        });

        if (p.status === "completed" && p.user_id && p.video_url) {
          await supabaseAdmin.from("videos").insert({
            user_id: p.user_id,
            title: p.title ?? "Vídeo gerado",
            video_url: p.video_url,
            thumbnail_url: p.thumbnail_url ?? null,
            status: "completed",
          });
        }

        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
