import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { Loader2, Save, Send, Trash2, FlaskConical, Upload, X, ImageIcon } from "lucide-react";

import { AppShell, PageHeader, useRequireAuth } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { checkIsAdmin } from "@/lib/admin.functions";
import { checkMyQuota } from "@/lib/quota.functions";
import { triggerVideoGeneration, getJobStatus } from "@/lib/video-generation.functions";
import { UpgradeModal } from "@/components/upgrade-modal";

export const Route = createFileRoute("/_authenticated/generator")({
  head: () => ({ meta: [{ title: "Gerador • ViralFlow" }] }),
  component: GeneratorPage,
});

type PlatformId = "youtube" | "tiktok" | "instagram" | "kwai" | "pinterest" | "rumble";
const PLATFORMS: { id: PlatformId; label: string }[] = [
  { id: "youtube", label: "YouTube" },
  { id: "tiktok", label: "TikTok" },
  { id: "instagram", label: "Instagram" },
  { id: "kwai", label: "Kwai" },
  { id: "pinterest", label: "Pinterest" },
  { id: "rumble", label: "Rumble" },
];

const LS_ENABLED = "viralflow.platforms.enabled";
const LS_KEYS = "viralflow.platforms.apiKeys";

const defaultEnabled = (): Record<PlatformId, boolean> => ({
  youtube: true, tiktok: true, instagram: false, kwai: false, pinterest: false, rumble: false,
});
const emptyKeys = (): Record<PlatformId, string> => ({
  youtube: "", tiktok: "", instagram: "", kwai: "", pinterest: "", rumble: "",
});

const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];

function GeneratorPage() {
  const { t } = useTranslation();
  const { user, loading } = useRequireAuth();

  const [niche, setNiche] = useState("");
  const [title, setTitle] = useState("");
  const [prompt, setPrompt] = useState("");
  const [cta, setCta] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const [enabled, setEnabled] = useState<Record<PlatformId, boolean>>(defaultEnabled());
  const [keys, setKeys] = useState<Record<PlatformId, string>>(emptyKeys());
  const [submitting, setSubmitting] = useState<null | "prod" | "test">(null);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  const [upgradeReason, setUpgradeReason] = useState<"quota" | "no_plan" | "image_limit">("quota");
  const [activeJobId, setActiveJobId] = useState<string | null>(null);

  const checkAdminFn = useServerFn(checkIsAdmin);
  const adminQ = useQuery({
    queryKey: ["isAdmin", user?.id],
    queryFn: () => checkAdminFn(),
    enabled: !!user,
    staleTime: 60_000,
  });
  const isAdmin = adminQ.data?.isAdmin === true;

  const checkQuotaFn = useServerFn(checkMyQuota);
  const quotaQ = useQuery({
    queryKey: ["quota", user?.id],
    queryFn: () => checkQuotaFn(),
    enabled: !!user,
    staleTime: 30_000,
  });

  const triggerFn = useServerFn(triggerVideoGeneration);
  const getJobFn = useServerFn(getJobStatus);

  const jobQ = useQuery({
    queryKey: ["job", activeJobId],
    queryFn: () => getJobFn({ data: { jobId: activeJobId! } }),
    enabled: !!activeJobId,
    refetchInterval: (q) => {
      const s = q.state.data?.status;
      return s === "completed" || s === "failed" ? false : 4000;
    },
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const e = localStorage.getItem(LS_ENABLED);
      if (e) setEnabled({ ...defaultEnabled(), ...JSON.parse(e) });
      const k = localStorage.getItem(LS_KEYS);
      if (k) setKeys({ ...emptyKeys(), ...JSON.parse(k) });
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") localStorage.setItem(LS_ENABLED, JSON.stringify(enabled));
  }, [enabled]);

  const selectedPlatforms = useMemo(
    () => PLATFORMS.filter((p) => enabled[p.id]).map((p) => p.id),
    [enabled],
  );

  const maxImages = quotaQ.data?.own_images_per_video ?? 0;

  const saveKey = (id: PlatformId) => {
    const next = { ...keys, [id]: keys[id] };
    localStorage.setItem(LS_KEYS, JSON.stringify(next));
    toast.success(`API Key de ${labelOf(id)} salva localmente`);
  };
  const removeKey = (id: PlatformId) => {
    const next = { ...keys, [id]: "" };
    localStorage.setItem(LS_KEYS, JSON.stringify(next));
    setKeys((k) => ({ ...k, [id]: "" }));
  };

  async function handleFiles(files: FileList | null) {
    if (!files || !user) return;
    if (maxImages === 0) {
      setUpgradeReason("no_plan");
      setUpgradeOpen(true);
      return;
    }
    const remaining = maxImages - images.length;
    if (remaining <= 0) {
      setUpgradeReason("image_limit");
      setUpgradeOpen(true);
      return;
    }
    const toUpload = Array.from(files).slice(0, remaining);
    setUploading(true);
    try {
      const urls: string[] = [];
      for (const file of toUpload) {
        if (!ALLOWED_TYPES.includes(file.type)) {
          toast.error(`${file.name}: tipo de arquivo inválido (apenas JPG, PNG, WEBP).`);
          continue;
        }
        if (file.size > MAX_IMAGE_SIZE) {
          toast.error(`${file.name}: máximo 10MB.`);
          continue;
        }
        const path = `${user.id}/generator/${Date.now()}-${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
        const { error: upErr } = await supabase.storage.from("user-media").upload(path, file, {
          contentType: file.type,
          upsert: false,
        });
        if (upErr) { toast.error(`Upload falhou: ${upErr.message}`); continue; }
        const { data: signed } = await supabase.storage.from("user-media").createSignedUrl(path, 60 * 60 * 24);
        if (signed?.signedUrl) urls.push(signed.signedUrl);
      }
      if (urls.length) setImages((arr) => [...arr, ...urls]);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function send(target: "prod" | "test") {
    if (!niche.trim() || !title.trim()) { toast.error("Informe nicho e título."); return; }
    if (selectedPlatforms.length === 0) { toast.error("Ative ao menos uma plataforma."); return; }

    setSubmitting(target);
    try {
      const result = await triggerFn({
        data: {
          nicho: niche.trim(),
          titulo: title.trim(),
          prompt: prompt.trim(),
          cta: cta.trim(),
          quantidade: target === "test" ? 1 : quantity,
          redes: selectedPlatforms,
          imagens: images,
        },
      });
      if (!result.ok) {
        if (result.code === "quota_exceeded") { setUpgradeReason("quota"); setUpgradeOpen(true); }
        else if (result.code === "no_plan") { setUpgradeReason("no_plan"); setUpgradeOpen(true); }
        else if (result.code === "image_limit_exceeded") { setUpgradeReason("image_limit"); setUpgradeOpen(true); }
        else toast.error(result.message);
        return;
      }
      setActiveJobId(result.job_id);
      toast.success("Geração iniciada. Acompanhe o progresso abaixo.");
      quotaQ.refetch();
    } catch (err) {
      toast.error(`Falha: ${(err as Error).message}`);
    } finally {
      setSubmitting(null);
    }
  }

  if (loading || !user) {
    return <div className="min-h-screen grid place-items-center"><Loader2 className="size-6 animate-spin text-muted-foreground" /></div>;
  }

  const q = quotaQ.data;

  return (
    <AppShell user={user}>
      <UpgradeModal open={upgradeOpen} onOpenChange={setUpgradeOpen} reason={upgradeReason} />
      <div className="p-6 md:p-10 max-w-5xl">
        <PageHeader
          title={t("generator.title")}
          subtitle={t("generator.subtitle")}
          action={
            q ? (
              <div className="flex flex-col items-end gap-1 text-xs">
                <Badge variant="secondary">{q.plan?.toUpperCase() ?? "—"}</Badge>
                <span className="text-muted-foreground">{t("generator.quotaMonthly", { used: q.monthly_used, max: q.monthly_limit })}</span>
                <span className="text-muted-foreground">{t("generator.quotaDaily", { used: q.daily_used, max: q.daily_limit })}</span>
              </div>
            ) : null
          }
        />

        <div className="grid gap-6">
          {activeJobId && jobQ.data && (
            <Card>
              <CardHeader>
                <CardTitle>{t("generator.processing")}</CardTitle>
                <CardDescription>Job {activeJobId.slice(0, 8)} · {jobQ.data.status}</CardDescription>
              </CardHeader>
              <CardContent>
                {jobQ.data.status === "failed" ? (
                  <p className="text-sm text-destructive">{jobQ.data.error_message ?? "Erro desconhecido"}</p>
                ) : jobQ.data.status === "completed" ? (
                  <p className="text-sm text-green-500">Concluído. Veja seu vídeo no Histórico.</p>
                ) : (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="size-4 animate-spin" />
                    Progresso: {jobQ.data.progress ?? 0}%
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Configuração do vídeo</CardTitle>
              <CardDescription>Defina nicho, título e roteiro. Adicione imagens próprias dentro do limite do seu plano.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="niche">{t("generator.niche")}</Label>
                <Input id="niche" value={niche} onChange={(e) => setNiche(e.target.value)} maxLength={120} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="title">{t("generator.videoTitle")}</Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="prompt">{t("generator.prompt")}</Label>
                <Textarea id="prompt" rows={4} value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={4000} />
              </div>
              <div className="grid gap-2 md:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="cta">{t("generator.cta")}</Label>
                  <Input id="cta" value={cta} onChange={(e) => setCta(e.target.value)} maxLength={300} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="qty">Quantidade</Label>
                  <Input id="qty" type="number" min={1} max={Math.max(1, q?.daily_limit ?? 1)} value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Math.min(30, Number(e.target.value) || 1)))} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><ImageIcon className="size-4" /> {t("generator.ownImages")}</CardTitle>
              <CardDescription>
                {t("generator.imagesCount", { used: images.length, max: maxImages })}
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3">
              <div className="flex items-center gap-3">
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" multiple
                  className="hidden" onChange={(e) => handleFiles(e.target.files)} />
                <Button type="button" variant="secondary" onClick={() => fileRef.current?.click()}
                  disabled={uploading || images.length >= maxImages}>
                  {uploading ? <Loader2 className="size-4 mr-2 animate-spin" /> : <Upload className="size-4 mr-2" />}
                  Adicionar imagens
                </Button>
                {images.length >= maxImages && maxImages > 0 && (
                  <span className="text-xs text-muted-foreground">Limite do plano atingido</span>
                )}
              </div>
              {images.length > 0 && (
                <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                  {images.map((url, i) => (
                    <div key={url} className="relative aspect-square rounded-md overflow-hidden border border-border">
                      <img src={url} alt="" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => setImages((arr) => arr.filter((_, idx) => idx !== i))}
                        className="absolute top-1 right-1 rounded-full bg-background/80 p-1 hover:bg-background">
                        <X className="size-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("generator.platforms")}</CardTitle>
              <CardDescription>Marque as redes de destino. As API Keys ficam apenas no seu navegador.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              {PLATFORMS.map((p) => (
                <div key={p.id} className="rounded-lg border border-border p-4 grid gap-3 md:grid-cols-[auto_1fr_auto] md:items-center">
                  <div className="flex items-center gap-3">
                    <Checkbox id={`chk-${p.id}`} checked={enabled[p.id]}
                      onCheckedChange={(v) => setEnabled((e) => ({ ...e, [p.id]: Boolean(v) }))} />
                    <Label htmlFor={`chk-${p.id}`} className="text-base font-medium cursor-pointer">{p.label}</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Input type="password" placeholder={`API Key do ${p.label}`} value={keys[p.id]}
                      onChange={(e) => setKeys((k) => ({ ...k, [p.id]: e.target.value }))} />
                    <Button type="button" variant="secondary" size="icon" onClick={() => saveKey(p.id)}><Save className="size-4" /></Button>
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeKey(p.id)}><Trash2 className="size-4" /></Button>
                  </div>
                  <div className="flex items-center gap-2 justify-end">
                    <Switch checked={enabled[p.id]} onCheckedChange={(v) => setEnabled((e) => ({ ...e, [p.id]: v }))} />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="flex flex-wrap gap-3 justify-end">
            {isAdmin && (
              <Button variant="outline" onClick={() => send("test")} disabled={submitting !== null}>
                {submitting === "test" ? <Loader2 className="size-4 mr-2 animate-spin" /> : <FlaskConical className="size-4 mr-2" />}
                {t("generator.generateTest")}
              </Button>
            )}
            <Button onClick={() => send("prod")} disabled={submitting !== null}>
              {submitting === "prod" ? <Loader2 className="size-4 mr-2 animate-spin" /> : <Send className="size-4 mr-2" />}
              {t("generator.generate")}
            </Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function labelOf(id: PlatformId) {
  return PLATFORMS.find((p) => p.id === id)?.label ?? id;
}
