import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { Check, Loader2 } from "lucide-react";

import { listPlans, getMyPlan, type PlanRow } from "@/lib/plans.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LanguageSwitcher } from "@/components/language-switcher";
import { currencyForLanguage, formatPrice } from "@/i18n";

export const Route = createFileRoute("/pricing")({
  head: () => ({ meta: [{ title: "Planos • ViralFlow" }] }),
  component: PricingPage,
});

function priceForCurrency(plan: PlanRow, currency: "BRL" | "USD" | "EUR") {
  switch (currency) {
    case "USD": return plan.price_usd_cents;
    case "EUR": return plan.price_eur_cents;
    default: return plan.price_brl_cents;
  }
}

function PricingPage() {
  const { t, i18n } = useTranslation();
  const currency = currencyForLanguage(i18n.language);

  const listFn = useServerFn(listPlans);
  const myPlanFn = useServerFn(getMyPlan);

  const plansQ = useQuery({ queryKey: ["plans"], queryFn: () => listFn() });
  const myPlanQ = useQuery({
    queryKey: ["myPlan"],
    queryFn: () => myPlanFn().catch(() => ({ plan: null })),
    retry: false,
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="font-display font-semibold text-lg">ViralFlow</Link>
          <div className="flex items-center gap-2">
            <LanguageSwitcher />
            <Link to="/login"><Button variant="ghost" size="sm">{t("auth.signin")}</Button></Link>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="font-display text-4xl font-semibold">{t("pricing.title")}</h1>
          <p className="text-muted-foreground mt-2">{t("pricing.subtitle")}</p>
        </div>

        {plansQ.isLoading ? (
          <div className="flex justify-center"><Loader2 className="size-6 animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {(plansQ.data ?? []).map((plan) => {
              const cents = priceForCurrency(plan, currency);
              const isCurrent = myPlanQ.data?.plan === plan.slug;
              const checkoutUrl = plan.checkout_url_kiwify || plan.checkout_url_stripe;
              return (
                <Card key={plan.slug} className={isCurrent ? "border-primary" : ""}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>{plan.name}</CardTitle>
                      {isCurrent && <Badge>{t("pricing.current")}</Badge>}
                    </div>
                    <div className="pt-2">
                      <span className="text-3xl font-bold">{formatPrice(cents, currency, i18n.language)}</span>
                      <span className="text-muted-foreground text-sm">{t("pricing.perMonth")}</span>
                    </div>
                    <CardDescription className="pt-2">
                      {t("pricing.videosPerMonth", { count: plan.videos_per_month })} ·{" "}
                      {t("pricing.videosPerDay", { count: plan.videos_per_day })}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-sm font-medium">{t("pricing.includes")}</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex gap-2"><Check className="size-4 text-primary shrink-0 mt-0.5" />{t("pricing.ownImages", { count: plan.own_images_per_video })}</li>
                      {plan.features.map((f) => (
                        <li key={f} className="flex gap-2">
                          <Check className="size-4 text-primary shrink-0 mt-0.5" />
                          {t(`features.${f}`, { defaultValue: f })}
                        </li>
                      ))}
                    </ul>
                    {checkoutUrl ? (
                      <Button asChild className="w-full" disabled={isCurrent}>
                        <a href={checkoutUrl} target="_blank" rel="noopener noreferrer">
                          {isCurrent ? t("pricing.current") : t("pricing.subscribe")}
                        </a>
                      </Button>
                    ) : (
                      <Button className="w-full" disabled title={t("pricing.comingSoon")}>
                        {t("pricing.comingSoon")}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
