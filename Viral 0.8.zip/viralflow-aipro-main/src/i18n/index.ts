import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";

import ptBR from "./locales/pt-BR.json";
import enUS from "./locales/en-US.json";
import es from "./locales/es.json";

export const SUPPORTED_LANGUAGES = [
  { code: "pt-BR", label: "Português (BR)", currency: "BRL" as const },
  { code: "en-US", label: "English (US)", currency: "USD" as const },
  { code: "es", label: "Español", currency: "EUR" as const },
];

export type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number]["code"];
export type SupportedCurrency = (typeof SUPPORTED_LANGUAGES)[number]["currency"];

if (!i18n.isInitialized) {
  i18n
    .use(LanguageDetector)
    .use(initReactI18next)
    .init({
      resources: {
        "pt-BR": { translation: ptBR },
        "en-US": { translation: enUS },
        es: { translation: es },
      },
      fallbackLng: "pt-BR",
      supportedLngs: ["pt-BR", "en-US", "es"],
      interpolation: { escapeValue: false },
      detection: {
        order: ["localStorage", "navigator"],
        lookupLocalStorage: "viralflow.lang",
        caches: ["localStorage"],
      },
    });
}

export function currencyForLanguage(lang: string): SupportedCurrency {
  return SUPPORTED_LANGUAGES.find((l) => l.code === lang)?.currency ?? "BRL";
}

export function formatPrice(cents: number, currency: SupportedCurrency, lang: string) {
  return new Intl.NumberFormat(lang, {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(cents / 100);
}

export default i18n;
