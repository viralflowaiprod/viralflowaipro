import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type QuotaInfo = {
  ok: boolean;
  reason: string | null;
  plan: string | null;
  monthly_used: number;
  monthly_limit: number;
  daily_used: number;
  daily_limit: number;
  own_images_per_video: number;
};

export const checkMyQuota = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<QuotaInfo> => {
    const { data, error } = await context.supabase.rpc("check_video_quota", {
      _user_id: context.userId,
    });
    if (error) throw new Error(error.message);
    const r = (data ?? {}) as Partial<QuotaInfo>;
    return {
      ok: r.ok ?? false,
      reason: r.reason ?? "no_active_plan",
      plan: r.plan ?? null,
      monthly_used: r.monthly_used ?? 0,
      monthly_limit: r.monthly_limit ?? 0,
      daily_used: r.daily_used ?? 0,
      daily_limit: r.daily_limit ?? 0,
      own_images_per_video: r.own_images_per_video ?? 0,
    };
  });
