import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

export type PlanRow = {
  slug: string;
  name: string;
  tier_order: number;
  price_brl_cents: number;
  price_usd_cents: number;
  price_eur_cents: number;
  videos_per_month: number;
  videos_per_day: number;
  own_images_per_video: number;
  features: string[];
  checkout_url_kiwify: string | null;
  checkout_url_stripe: string | null;
};

export const listPlans = createServerFn({ method: "GET" }).handler(async (): Promise<PlanRow[]> => {
  const supabase = createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
  const { data, error } = await supabase
    .from("plans")
    .select(
      "slug,name,tier_order,price_brl_cents,price_usd_cents,price_eur_cents,videos_per_month,videos_per_day,own_images_per_video,features,checkout_url_kiwify,checkout_url_stripe",
    )
    .eq("is_active", true)
    .order("tier_order", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []).map((p) => ({
    ...p,
    features: Array.isArray(p.features) ? (p.features as string[]) : [],
  }));
});

export const getMyPlan = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.rpc("get_user_plan", {
      _user_id: context.userId,
    });
    if (error) throw new Error(error.message);
    return { plan: (data as string | null) ?? null };
  });
