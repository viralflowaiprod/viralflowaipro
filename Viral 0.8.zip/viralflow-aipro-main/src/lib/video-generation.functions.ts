import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const N8N_WEBHOOK_URL = "https://viralflowaipro.app.n8n.cloud/webhook/viralflow";

const InputSchema = z.object({
  nicho: z.string().trim().min(1).max(120),
  titulo: z.string().trim().min(1).max(200),
  prompt: z.string().trim().max(4000).default(""),
  cta: z.string().trim().max(300).default(""),
  quantidade: z.number().int().min(1).max(30).default(1),
  redes: z.array(z.string().min(1).max(40)).max(20).default([]),
  imagens: z.array(z.string().url()).max(20).default([]),
});

export type GenerateVideoResult =
  | { ok: true; job_id: string }
  | { ok: false; code: "quota_exceeded" | "no_plan" | "image_limit_exceeded" | "rate_limited" | "n8n_failed"; message: string };

export const triggerVideoGeneration = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => InputSchema.parse(d))
  .handler(async ({ data, context }): Promise<GenerateVideoResult> => {
    const { supabase, userId } = context;

    // Rate limit: 10 generations per minute per user (sensitive op)
    {
      const { data: allowed, error } = await supabase.rpc("check_rate_limit", {
        _bucket: "video_gen",
        _identifier: userId,
        _max: 10,
        _window_seconds: 60,
      });
      if (error) throw new Error(error.message);
      if (!allowed) {
        return { ok: false, code: "rate_limited", message: "Muitas requisições. Aguarde 1 minuto." };
      }
    }

    // Quota check
    const { data: quota, error: qErr } = await supabase.rpc("check_video_quota", { _user_id: userId });
    if (qErr) throw new Error(qErr.message);
    const q = quota as { ok: boolean; reason: string | null; own_images_per_video: number; plan: string | null };
    if (!q || q.plan === null) {
      return { ok: false, code: "no_plan", message: "Plano ativo necessário." };
    }
    if (!q.ok) {
      return { ok: false, code: "quota_exceeded", message: "Limite do plano atingido." };
    }
    if (data.imagens.length > q.own_images_per_video) {
      return {
        ok: false,
        code: "image_limit_exceeded",
        message: `Seu plano permite no máximo ${q.own_images_per_video} imagens próprias por vídeo.`,
      };
    }

    // Create job
    const { data: job, error: jobErr } = await supabase
      .from("video_jobs")
      .insert({
        user_id: userId,
        niche: data.nicho,
        topic: data.titulo,
        cta: data.cta,
        prompt: data.prompt,
        quantity: data.quantidade,
        platform: data.redes.join(","),
        reference_images: data.imagens,
        status: "queued",
        payload: data,
      })
      .select("id")
      .single();
    if (jobErr || !job) throw new Error(jobErr?.message ?? "Failed to create job");

    // Audit
    await supabase.rpc("log_audit_event", {
      _user_id: userId,
      _action: "video.generate",
      _target_type: "video_job",
      _target_id: job.id,
      _metadata: { plan: q.plan, redes: data.redes, imagens: data.imagens.length },
    });

    // Send to N8N
    const webhookSecret = process.env.N8N_WEBHOOK_SECRET ?? "";
    const callbackBase = process.env.PUBLIC_APP_URL ?? "";
    try {
      const res = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Webhook-Secret": webhookSecret,
        },
        body: JSON.stringify({
          job_id: job.id,
          user_id: userId,
          callback_secret: webhookSecret,
          callback_url: callbackBase ? `${callbackBase}/api/public/hooks/video-progress` : undefined,
          nicho: data.nicho,
          titulo: data.titulo,
          prompt: data.prompt,
          quantidade: data.quantidade,
          cta: data.cta,
          redes: data.redes,
          imagens: data.imagens,
        }),
      });
      if (!res.ok) throw new Error(`N8N HTTP ${res.status}`);
    } catch (err) {
      await supabase
        .from("video_jobs")
        .update({
          status: "failed",
          error_message: err instanceof Error ? err.message : "N8N dispatch failed",
        })
        .eq("id", job.id);
      return { ok: false, code: "n8n_failed", message: "Falha ao iniciar processamento. Tente novamente." };
    }

    return { ok: true, job_id: job.id };
  });

export const getJobStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ jobId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: job, error } = await context.supabase
      .from("video_jobs")
      .select("id,status,progress,error_message,topic,created_at,updated_at")
      .eq("id", data.jobId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return job;
  });
