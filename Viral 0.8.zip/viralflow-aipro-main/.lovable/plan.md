
Este é um escopo grande. Vou entregar em fases coerentes, sem remover funcionalidades nem mudar o layout. Resumo do que será feito e como.

## 1. Planos (Standard / Premium / Master)

Criar no banco a tabela `plans` (slug, nome, preço BRL/USD/EUR, limites, features JSON) e popular com os 3 planos Founder nos valores informados (R$ 29 / R$ 79 / R$ 349,90).

Estender `subscriptions` com `plan_slug` e helpers:
- `get_user_plan(uuid)` → retorna plano efetivo (admin = master; sem assinatura ativa = `free`/bloqueado).
- `check_quota(user_id, kind)` → valida limites mensais/diários (`videos_per_month`, `videos_per_day`, `own_images_per_video`).

Contadores diários/mensais derivados de `videos` + `video_jobs` (não criar contador mutável separado para evitar drift).

## 2. Limites e bloqueio

Server function `enforceVideoQuota` chamada antes de cada geração. Se estourar:
- API responde 403 com `code: "quota_exceeded"`.
- Front exibe modal: "Você atingiu o limite do seu plano. Faça upgrade para continuar." + botão **FAZER UPGRADE** → `/pricing`.

Gerador de vídeos: contador visual de imagens próprias (`X / limite`) baseado no plano. Botão desabilita ao atingir.

## 3. Checkout (Kiwify + Stripe — estrutura, sem mock)

Página `/pricing` com 3 cards e botão **ASSINAR PLANO**. URLs vêm de `plans.checkout_url_kiwify` e `plans.checkout_url_stripe` (configuráveis no admin; vazias por padrão — botão fica desabilitado com tooltip "Checkout em configuração" até o admin colar a URL).

Webhook real `/api/public/webhooks/payments/$provider` já existe; ativar tratamento para os 3 planos por slug, com verificação de assinatura (Kiwify token / Stripe signature). Nada de pagamento mockado.

## 4. Internacionalização (pt-BR, en-US, es)

Adicionar `i18next` + `react-i18next` + detector de idioma.
- Arquivos `src/i18n/locales/{pt-BR,en-US,es}.json`.
- Provider em `__root.tsx`.
- Seletor de idioma no header (persistido em `profiles.locale`).
- Refatorar strings das telas principais (auth, dashboard, gerador, agenda, histórico, admin, pricing) para `t("...")`. Telas restantes ficam com fallback pt-BR (não quebra layout).

Moedas: tabela `plans` já tem `price_brl/usd/eur`; helper `formatCurrency(locale)` escolhe moeda conforme idioma. Sem conversão dinâmica.

## 5. Conta administradora exclusiva

Trocar admin para `juliofagundes005@gmail.com`:
- Migration promove esse e-mail a `admin` (se já existir em `auth.users`); senão, trigger `handle_new_user` promove no primeiro signup.
- Remover automaticamente o admin antigo (`viralflowai.prod@gmail.com`) — confirmar com você antes de aplicar se preferir manter.

Gates de UI por `is_admin()`:
- "Gerar Vídeo Teste", "Ferramentas Beta", "Recursos internos/experimentais" só renderizam se `hasRole("admin")`.
- Rotas admin já protegidas por `_authenticated/admin` + RLS; reforçar com `requireSupabaseAuth` + check de role nas server fns.

## 6. Gerador → Webhook N8N real

Server function `triggerVideoGeneration`:
1. Valida input com Zod (nicho, titulo, prompt, quantidade 1–N, cta, redes[], imagens[] URLs).
2. `enforceVideoQuota`.
3. Insere `video_jobs` (status `queued`, retorna `id`).
4. POST para `https://viralflowaipro.app.n8n.cloud/webhook/viralflow` com payload exato + `job_id` + `callback_url` + header `X-Webhook-Secret` (gerado).
5. Retorna `job_id` ao front.

Front:
- Tela de processamento com polling de `video_jobs.status`.
- Exibe vídeo pronto (`output_url`) ou erro (`error_message`).

Callback do N8N → rota pública `/api/public/hooks/video-progress` (já existe) valida `X-Webhook-Secret` e atualiza job.

## 7. Segurança (hardening de produção)

- **Validação de entrada**: Zod em toda server fn / rota pública.
- **XSS**: nenhum `dangerouslySetInnerHTML` com input do usuário; sanitizar markdown se houver.
- **CSRF**: server fns same-origin + bearer token; rotas públicas usam assinatura HMAC.
- **Uploads**: bucket `user-media` privado, RLS por `auth.uid()`, validar MIME (`image/jpeg|png|webp`) e tamanho ≤ 10MB no client e server (signed upload com policy).
- **RBAC**: `has_role` already SECURITY DEFINER; revogar EXECUTE de anon (já feito em migration anterior); reforçar checks em todas as fns admin.
- **Rate limiting**: ad-hoc por usuário/IP em tabela `rate_limits` (Lovable não tem primitivo padrão — confirmo o tradeoff). Aplicado em: signup, login (já tem do Supabase), trigger de vídeo, webhook.
- **Audit log**: tabela `audit_logs` (user_id, action, target, metadata, ip, ua) gravada por trigger em ações sensíveis (promoção de role, mudança de plano, geração de vídeo, alteração de API keys).
- **Webhooks**: HMAC obrigatório, timing-safe compare, rejeição de replay (timestamp ±5min).
- **Rotas privadas**: tudo sob `_authenticated/`; admin sob check extra.
- **Headers**: CSP/HSTS são gerenciados pela Lovable/Netlify; não tocar.

## 8. O que NÃO vou mexer

- Layout/visual atual das telas.
- Funcionalidades existentes (apenas adiciono gates e validações).
- Auto-gen Supabase (`client.ts`, `types.ts`, etc).

---

## Detalhes técnicos (para referência)

**Migrations** (1 sola migration grande, aprovação única):
- `plans` table + GRANTs + RLS (SELECT anon p/ leitura pública, ALL service_role).
- `subscriptions.plan_slug` FK.
- `audit_logs` + `rate_limits` + GRANTs + RLS.
- `profiles.locale` (default 'pt-BR').
- Helpers SQL: `get_user_plan`, `check_quota`, `log_audit`.
- Promover `juliofagundes005@gmail.com` (e atualizar `handle_new_user`).
- Seed dos 3 planos Founder.

**Server fns novas** (`src/lib/`):
- `plans.functions.ts` — listar planos, plano atual.
- `quota.functions.ts` — checar quota.
- `video-generation.functions.ts` — disparar N8N.
- `admin.functions.ts` — já existe; estender com set checkout URLs.
- `audit.server.ts` — helper de log.

**Rotas novas**:
- `src/routes/pricing.tsx` (pública).
- `src/routes/_authenticated/upgrade.tsx` (modal/page).

**Secrets a adicionar** (vou pedir com `add_secret`):
- `N8N_WEBHOOK_SECRET` (gerado).
- `KIWIFY_WEBHOOK_SECRET` (você cola depois do setup).
- `STRIPE_WEBHOOK_SECRET` (idem).

---

## Confirme antes de eu começar

1. **Admin antigo** `viralflowai.prod@gmail.com`: remover role `admin` ou manter os dois como admin?
2. **Rate limiting**: a Lovable não tem primitivo padrão; vou implementar ad-hoc em tabela Postgres (custo: 1 query extra por request sensível). OK?
3. **i18n**: refatoro só telas principais agora (auth, dashboard, gerador, agenda, histórico, admin, pricing) e deixo o restante para depois — ou quer tudo de uma vez (mais lento)?
4. **URLs de checkout** Kiwify/Stripe: deixo vazias para você preencher no painel admin, certo?

Responda essas 4 e eu executo tudo em sequência.
