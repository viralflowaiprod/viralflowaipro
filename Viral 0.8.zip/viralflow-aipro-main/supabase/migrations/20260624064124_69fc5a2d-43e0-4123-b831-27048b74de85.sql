
-- 1. PLANS catalog
CREATE TABLE public.plans (
  slug text PRIMARY KEY,
  name text NOT NULL,
  tier_order int NOT NULL,
  price_brl_cents int NOT NULL DEFAULT 0,
  price_usd_cents int NOT NULL DEFAULT 0,
  price_eur_cents int NOT NULL DEFAULT 0,
  videos_per_month int NOT NULL DEFAULT 0,
  videos_per_day int NOT NULL DEFAULT 0,
  own_images_per_video int NOT NULL DEFAULT 0,
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  checkout_url_kiwify text,
  checkout_url_stripe text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.plans TO anon, authenticated;
GRANT ALL ON public.plans TO service_role;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "plans public read" ON public.plans FOR SELECT TO anon, authenticated USING (is_active = true);
CREATE POLICY "plans admin manage" ON public.plans FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_plans_updated BEFORE UPDATE ON public.plans
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Seed plans (Founder pricing)
INSERT INTO public.plans (slug, name, tier_order, price_brl_cents, price_usd_cents, price_eur_cents,
  videos_per_month, videos_per_day, own_images_per_video, features) VALUES
('standard', 'Standard', 1, 2900, 599, 549, 90, 3, 5,
  '["pexels_library","pixabay_library","manual_generation","ai_narration","auto_captions","post_schedule","video_history"]'::jsonb),
('premium', 'Premium', 2, 7900, 1599, 1499, 300, 10, 10,
  '["pexels_library","pixabay_library","manual_generation","ai_narration","auto_captions","post_schedule","video_history","auto_cta","auto_hashtags","content_variations","priority_processing","advanced_schedule"]'::jsonb),
('master', 'Master', 3, 34990, 6999, 6499, 900, 30, 20,
  '["pexels_library","pixabay_library","manual_generation","ai_narration","auto_captions","post_schedule","video_history","auto_cta","auto_hashtags","content_variations","priority_processing","advanced_schedule","ai_scripts","ai_titles","ai_descriptions","ai_ctas","ai_hashtags","ai_auto_schedule","ai_auto_publish","multi_social"]'::jsonb);

-- 2. subscriptions.plan_slug
ALTER TABLE public.subscriptions ADD COLUMN plan_slug text REFERENCES public.plans(slug);
UPDATE public.subscriptions SET plan_slug = COALESCE(plan_tier, 'standard') WHERE plan_slug IS NULL;

-- 3. profiles.locale
ALTER TABLE public.profiles ADD COLUMN locale text NOT NULL DEFAULT 'pt-BR'
  CHECK (locale IN ('pt-BR','en-US','es'));

-- 4. AUDIT LOGS
CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL,
  target_type text,
  target_id text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX audit_logs_user_id_created_idx ON public.audit_logs (user_id, created_at DESC);
CREATE INDEX audit_logs_action_idx ON public.audit_logs (action, created_at DESC);

GRANT SELECT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "audit own select" ON public.audit_logs FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- 5. RATE LIMITS
CREATE TABLE public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bucket text NOT NULL,
  identifier text NOT NULL,
  window_start timestamptz NOT NULL DEFAULT now(),
  count int NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (bucket, identifier, window_start)
);

CREATE INDEX rate_limits_lookup_idx ON public.rate_limits (bucket, identifier, window_start DESC);

GRANT ALL ON public.rate_limits TO service_role;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
-- no policies = locked to service_role / SECURITY DEFINER

-- 6. Helpers

-- effective plan slug for a user (admin -> master, no active sub -> NULL)
CREATE OR REPLACE FUNCTION public.get_user_plan(_user_id uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE
    WHEN public.has_role(_user_id, 'admin') THEN 'master'
    ELSE (
      SELECT plan_slug FROM public.subscriptions
      WHERE user_id = _user_id AND status = 'active'
        AND (current_period_end IS NULL OR current_period_end > now())
      ORDER BY created_at DESC LIMIT 1
    )
  END;
$$;
REVOKE EXECUTE ON FUNCTION public.get_user_plan(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_user_plan(uuid) TO authenticated, service_role;

-- plan limits
CREATE OR REPLACE FUNCTION public.get_plan_limits(_slug text)
RETURNS TABLE(videos_per_month int, videos_per_day int, own_images_per_video int)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT videos_per_month, videos_per_day, own_images_per_video FROM public.plans WHERE slug = _slug;
$$;
REVOKE EXECUTE ON FUNCTION public.get_plan_limits(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_plan_limits(text) TO authenticated, service_role;

-- count user videos in a window
CREATE OR REPLACE FUNCTION public.count_videos_in_period(_user_id uuid, _since timestamptz)
RETURNS int LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COUNT(*)::int FROM public.video_jobs
  WHERE user_id = _user_id AND created_at >= _since AND status <> 'failed';
$$;
REVOKE EXECUTE ON FUNCTION public.count_videos_in_period(uuid, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.count_videos_in_period(uuid, timestamptz) TO authenticated, service_role;

-- quota check (returns json: {ok, reason, plan, monthly_used, monthly_limit, daily_used, daily_limit})
CREATE OR REPLACE FUNCTION public.check_video_quota(_user_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_plan text;
  v_limits record;
  v_monthly int;
  v_daily int;
BEGIN
  v_plan := public.get_user_plan(_user_id);
  IF v_plan IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'no_active_plan');
  END IF;
  SELECT * INTO v_limits FROM public.get_plan_limits(v_plan);
  v_monthly := public.count_videos_in_period(_user_id, date_trunc('month', now()));
  v_daily := public.count_videos_in_period(_user_id, date_trunc('day', now()));
  RETURN jsonb_build_object(
    'ok', v_monthly < v_limits.videos_per_month AND v_daily < v_limits.videos_per_day,
    'plan', v_plan,
    'monthly_used', v_monthly, 'monthly_limit', v_limits.videos_per_month,
    'daily_used', v_daily, 'daily_limit', v_limits.videos_per_day,
    'own_images_per_video', v_limits.own_images_per_video,
    'reason', CASE
      WHEN v_monthly >= v_limits.videos_per_month THEN 'monthly_limit_reached'
      WHEN v_daily >= v_limits.videos_per_day THEN 'daily_limit_reached'
      ELSE NULL END
  );
END; $$;
REVOKE EXECUTE ON FUNCTION public.check_video_quota(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.check_video_quota(uuid) TO authenticated, service_role;

-- audit logger (SECURITY DEFINER so callers can insert without direct INSERT priv)
CREATE OR REPLACE FUNCTION public.log_audit_event(
  _user_id uuid, _action text, _target_type text DEFAULT NULL,
  _target_id text DEFAULT NULL, _metadata jsonb DEFAULT '{}'::jsonb,
  _ip text DEFAULT NULL, _ua text DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.audit_logs(user_id, action, target_type, target_id, metadata, ip_address, user_agent)
  VALUES (_user_id, _action, _target_type, _target_id, _metadata, _ip, _ua)
  RETURNING id INTO v_id;
  RETURN v_id;
END; $$;
REVOKE EXECUTE ON FUNCTION public.log_audit_event(uuid, text, text, text, jsonb, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_audit_event(uuid, text, text, text, jsonb, text, text) TO authenticated, service_role;

-- rate limit checker: returns true if allowed, false if blocked. Window in seconds.
CREATE OR REPLACE FUNCTION public.check_rate_limit(
  _bucket text, _identifier text, _max int, _window_seconds int
) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_window_start timestamptz;
  v_count int;
BEGIN
  v_window_start := date_trunc('second', now()) - make_interval(secs => (extract(epoch from now())::int % _window_seconds));
  INSERT INTO public.rate_limits(bucket, identifier, window_start, count)
  VALUES (_bucket, _identifier, v_window_start, 1)
  ON CONFLICT (bucket, identifier, window_start)
  DO UPDATE SET count = public.rate_limits.count + 1
  RETURNING count INTO v_count;
  -- cleanup old windows opportunistically (older than 1 day)
  DELETE FROM public.rate_limits WHERE window_start < now() - interval '1 day';
  RETURN v_count <= _max;
END; $$;
REVOKE EXECUTE ON FUNCTION public.check_rate_limit(text, text, int, int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.check_rate_limit(text, text, int, int) TO authenticated, service_role;

-- 7. Promote admin emails
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role FROM auth.users
WHERE email IN ('juliofagundes005@gmail.com', 'viralflowai.prod@gmail.com')
ON CONFLICT (user_id, role) DO NOTHING;

-- 8. Update handle_new_user to auto-promote both admin emails
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  IF NEW.email IN ('juliofagundes005@gmail.com', 'viralflowai.prod@gmail.com') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;
