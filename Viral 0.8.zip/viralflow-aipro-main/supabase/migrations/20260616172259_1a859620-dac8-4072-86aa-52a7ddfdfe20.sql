
-- Lock down SECURITY DEFINER functions: revoke EXECUTE from public/anon
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_admin() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_active_subscription(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

-- Restrict sensitive columns on activation_codes from end users.
-- Buyer email and external order id may belong to a different person than the redeemer.
REVOKE SELECT (buyer_email, external_order_id) ON public.activation_codes FROM authenticated;
REVOKE SELECT (buyer_email, external_order_id) ON public.activation_codes FROM anon;
